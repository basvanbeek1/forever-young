for i in range (1,13):
    print (str(i) + ("AM"))
for i in range (1,13):
    print (str(i) + ("PM"))
    